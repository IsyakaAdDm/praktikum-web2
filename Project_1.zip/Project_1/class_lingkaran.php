<?php
    include_once 'header.php';
    include_once 'sidebar.php';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Lingkaran</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Lingkaran</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
<?php
    class Lingkaran { 
        private $jari;
        const PHI = 3.14;
        function __construct( $r )
        {
            $this->jari = $r;
        }
        function getLuas()
        {
            return self::PHI * $this->jari * $this->jari ;
        }
        function getKeliling()
        {
            return 2 * self::PHI * $this->jari;
        }
    }
    
    echo "NILAI PHI : " . Lingkaran::PHI;
    $lingkar1 = new Lingkaran( 10 );
    $lingkar2 = new Lingkaran( 4 );

    echo "<br/>Luas Lingkaran I : ".$lingkar1->getLuas();
    echo "<br>Luas Lingkaran II  : ".$lingkar2->getLuas();

    echo "<br/>Keliling Lingkaran I : ".$lingkar1->getKeliling();
    echo "<br>Keliling Lingkaran II : ".$lingkar2->getKeliling();
?>
<?php
    include_once 'footer.php';
?>
<?php
    include_once 'header.php';
    include_once 'sidebar.php';
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Persegi Panjang</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active">Nilai Persegi Panjang</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
<?php
class __persegipanjang{
    public $panjang;
    public $lebar;

    public function luaspp(){
        $luas=$this-> panjang*$this-> lebar;
        return "Luas : ".$luas;
    }
    public function kelilingpp(){
        $keliling=2*($this-> panjang + $this-> lebar);
        return "Keliling : ".$keliling;
    }
    public function settlebar($lebar){
        return $this->lebar = $lebar;
    }
    public function settpanjang($panjang){
        return $this->panjang = $panjang;
    }
}
$luaspersegi = new __persegipanjang();
echo "Panjang : ".$luaspersegi-> settpanjang(15);
echo "<br>";
echo "Lebar : ".$luaspersegi-> settlebar(10);
echo "<br>";
echo $luaspersegi-> luaspp();
echo "<br>";
echo $luaspersegi-> kelilingpp();
?>
<?php
    include_once 'footer.php';
?>